base {}

cube0 (base) { 
    shape: box, 
    size: [.1, .1, .1], 
    color: [1, 0, 0], 
    X: "t(0 0 0)" 
}
joint1(cube0):{
  joint: none,
  pre: "T t(0.0 0.0 0.0)"
}

cube1(joint1):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [0.0, 0.0, -0.1],
  X: "t(0.0 0.0 -0.1)"
}

joint2(cube1):{
  joint: none,
  pre: "T t(0.0 0.0 -0.1)"
}

cube2(joint2):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [-0.1, 0.0, -0.1],
  X: "t(-0.1 0.0 -0.1)"
}

joint3(cube2):{
  joint: none,
  pre: "T t(0.0 0.0 -0.1)"
}

cube3(joint3):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [0.0, 0.1, -0.1],
  X: "t(0.0 0.1 -0.1)"
}

joint4(cube3):{
  joint: none,
  pre: "T t(0.0 0.0 -0.1)"
}

cube4(joint4):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [0.1, 0.0, -0.1],
  X: "t(0.1 0.0 -0.1)"
}

joint5(cube4):{
  joint: none,
  pre: "T t(0.1 0.0 -0.1)"
}

cube5(joint5):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [0.1, 0.0, 0.0],
  X: "t(0.1 0.0 0.0)"
}

joint6(cube5):{
  joint: none,
  pre: "T t(-0.1 0.0 -0.1)"
}

cube6(joint6):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [-0.1, 0.0, -0.2],
  X: "t(-0.1 0.0 -0.2)"
}

joint7(cube6):{
  joint: none,
  pre: "T t(-0.1 0.0 -0.2)"
}

cube7(joint7):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [-0.1, -0.1, -0.2],
  X: "t(-0.1 -0.1 -0.2)"
}

joint8(cube7):{
  joint: none,
  pre: "T t(-0.1 -0.1 -0.2)"
}

cube8(joint8):{
  shape: box,
  size: [0.1, 0.1, 0.1],
  color: [1, 0, 1],
  position: [-0.2, -0.1, -0.2],
  X: "t(-0.2 -0.1 -0.2)"
}
